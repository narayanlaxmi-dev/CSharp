package com.movieflix.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.movieflix.dto.MovieDto;

public interface IMovieService {
	
	//add new movie
	MovieDto add(MovieDto movieDto, MultipartFile poster) throws IOException;

}
