package com.movieflix.dto;

import java.util.Date;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.movieflix.entity.Category;
import com.movieflix.entity.Genre;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class MovieDto {

	private Integer id;
	
	private String title;
	
	private String director;
	
	private String studio;
	
	@JsonFormat(shape = Shape.STRING, pattern = "dd-MM-yyyy")
	private Date releaseDate;
	
	private Float avgVote;
	
	private Set<String> cast;
	
	private Category category;
	
	private Set<Genre> genres;
	
	private String poster;
	
	private String posterUrl;
}
