package com.movieflix.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.movieflix.dto.MovieDto;
import com.movieflix.service.IMovieService;

@RestController
@RequestMapping("/movie")
public class MovieController {
	
	@Autowired
	private IMovieService movieService;

	@PostMapping("/add")
	public ResponseEntity<?> addMovie(@RequestPart String movieDto,
									  @RequestPart MultipartFile poster) 
											  throws IOException{
		if(poster.isEmpty()) {
			throw new RuntimeException("Poster is empty!!");
		}
		MovieDto dto = convertToMovieDto(movieDto);
		MovieDto savedMovieDto = movieService.add(dto, poster);
		return new ResponseEntity<>(savedMovieDto,HttpStatus.CREATED);
	}

	private MovieDto convertToMovieDto(String movieDto) 
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(movieDto, MovieDto.class);
	}
}
