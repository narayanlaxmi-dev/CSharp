package com.movieflix.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.movieflix.dao.CategoryRepository;
import com.movieflix.dao.GenreRepository;
import com.movieflix.dao.MovieRepository;
import com.movieflix.dto.MovieDto;
import com.movieflix.entity.Category;
import com.movieflix.entity.Genre;
import com.movieflix.entity.Movie;

@Service
public class MovieService implements IMovieService{
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private CategoryRepository categoryRepo;
	
	@Autowired
	private GenreRepository genreRepo;
	
	@Autowired
	private MovieRepository movieRepo;
	
	@Value("${file.upload.path}")
	private String uploadPath;

	@Override
	public MovieDto add(MovieDto movieDto, MultipartFile poster) throws IOException {
		// 1.upload poster for relative entity
		String originalNewFilename = poster.getOriginalFilename();
		String storePath = uploadPath+File.separator+originalNewFilename;
		if(Files.exists(Paths.get(storePath))) {
			throw new FileAlreadyExistsException
			("Poster already exist!! provide different poster.");
		}
		String uploadedFile = fileService.upload(poster);
		
		// 2.set uploaded file name to MovieDto
		movieDto.setPoster(uploadedFile);
		
		// 3.get the category or save the category if it is new
		Category category = categoryRepo.findByName(movieDto.getCategory().getName())
		.orElseGet(()-> categoryRepo.save(movieDto.getCategory()));
		
		// 4.get the genres or save genres if they are new
		Set<Genre> genres = movieDto.getGenres().stream().map(
					genre -> genreRepo.findByName(genre.getName())
					.orElseGet(()-> genreRepo.save(genre))
				).collect(Collectors.toSet());
		
		// 5.convert MovieDto to Movie
		Movie newMovie = new Movie();
		newMovie.setTitle(movieDto.getTitle());
		newMovie.setDirector(movieDto.getDirector());
		newMovie.setStudio(movieDto.getStudio());
		newMovie.setReleaseDate(movieDto.getReleaseDate());
		newMovie.setAvgVote(movieDto.getAvgVote());
		newMovie.setCast(movieDto.getCast());
		newMovie.setCategory(category);
		newMovie.setGenres(genres);
		newMovie.setPoster(movieDto.getPoster());
		
		// 6.save the movie
		Movie savedMovie = movieRepo.save(newMovie);
		
		// 7.create poster URL with poster of saved movie
		String posterUrl = "http://localhost:8086/file/"+savedMovie.getPoster();
		
		// 8.convert Movie to MovieDto
		MovieDto dto = MovieDto.builder()
						.id(savedMovie.getId())
						.title(savedMovie.getTitle())
						.director(savedMovie.getDirector())
						.studio(savedMovie.getStudio())
						.avgVote(savedMovie.getAvgVote())
						.releaseDate(savedMovie.getReleaseDate())
						.cast(savedMovie.getCast())
						.category(savedMovie.getCategory())
						.genres(savedMovie.getGenres())
						.poster(savedMovie.getPoster())
						.posterUrl(posterUrl)
						.build();
		
		// 9.return MovieDto
		return dto;
	}

}
