package com.movieflix.controller;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StreamUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.movieflix.service.FileService;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/file")
public class FileController {

	@Autowired
	private FileService fileservice;
	
	//http://localhost:8086/file/upload
	@PostMapping("/upload")
	public ResponseEntity<?> uploadPoster(@RequestParam MultipartFile poster) throws IOException{
		if(poster.isEmpty()) {
			throw new RuntimeException("Poster is Empty !");
			
		}
		String uploadedFilename = fileservice.Upload(poster);
		return new ResponseEntity<>(uploadedFilename,HttpStatus.CREATED);
	}
	//http://localhost:8086/file/MovieFlixPoster.jpg
	@GetMapping("/{fileName}")
	public ResponseEntity<?> getUloadedFile(@PathVariable String fileName, HttpServletResponse response) throws IOException{
		InputStream poster =  fileservice.getPoster(fileName);
		String ContentType = getFileContentType(fileName);
		response.setContentType(ContentType);
		
		return new ResponseEntity<>(StreamUtils.copy(poster, response.getOutputStream()),HttpStatus.CREATED);
	}
	
	
	private String getFileContentType(String fileName) {
		//movieFlixLogo.png
		
		Integer dotIndex =  fileName.lastIndexOf(".");
		String extension =  fileName.substring(dotIndex);
		
		String type  = null;
		switch (extension) {
		case ".png" : 
			
			type = "image/png";
			break;
			
		case ".jpg" : 
		case ".jpeg" : 
			type = "image/jpeg";
			break;
		default:
			type = "image/jpeg";
		}
		
		return type;
	}
}
