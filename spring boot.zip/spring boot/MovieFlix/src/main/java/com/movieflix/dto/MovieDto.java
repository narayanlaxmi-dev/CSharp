package com.movieflix.dto;


import java.util.Date;
import java.util.Optional;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.movieflix.entity.Category;
import com.movieflix.entity.Genre;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MovieDto {
	

	private Integer id;

	private String title;
	
	private String director;
	
	private String studio;
	
	@JsonFormat(shape = Shape.STRING,pattern = "dd-mm-yyyy")
	private Date releaseDate;
	
	private Float avgVote;
	

	private Set<String> cast;
	
	
	private Category category;

	private Set<Genre> generes;
	
	private String poster;

	public Optional<Category> getGenres() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	
	
	
}


