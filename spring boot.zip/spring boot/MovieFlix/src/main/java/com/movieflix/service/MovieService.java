package com.movieflix.service;

import java.io.IOException;
import java.util.Set;
import java.util.stream.Collectors;  // Ensure this import is here

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.movieflix.dao.CategoryRepository;
import com.movieflix.dao.GenreRepository;
import com.movieflix.dao.MovieRepository;
import com.movieflix.dto.MovieDto;
import com.movieflix.entity.Category;
import com.movieflix.entity.Genre;
import com.movieflix.entity.Movie;

@Service
public class MovieService implements IMovieService {

    @Autowired
    private FileService fileService;

    @Autowired
    private CategoryRepository categoryRepo;

    @Autowired
    private GenreRepository genreRepo;

    @Override
    public MovieDto add(MovieDto movieDto, MultipartFile poster) throws IOException {
        // 1. Upload poster for relative entity
        String uploadedFile = fileService.Upload(poster);
        // 2. Set uploaded file name to MovieDto
        movieDto.setPoster(uploadedFile);
        // 3. Get the category or save the category if it is new
        Category category = categoryRepo.findByName(movieDto.getCategory().getName())
                .orElseGet(() -> categoryRepo.save(movieDto.getCategory()));
        // 4. Get the genres or save the genres if it is new
        Set<Genre> genres = movieDto.getGenres().stream()
        	    .map(genreDto -> {
        	        // Create Genre entity from DTO
        	        Genre genreEntity = new Genre();
        	        genreEntity.setName(genreDto.getName());

        	        // Try to find by name, or save if not found
        	        return genreRepo.findByName(genreEntity.getName())
        	                .orElseGet(() -> genreRepo.save(genreEntity));
        	    })
        	    .collect(Collectors.toSet());

        

        // 5. Convert MovieDto to Movie (you may need to implement this)
        Movie newMovie = new Movie();
        newMovie.setTitle(movieDto.getTitle());
        newMovie.setDirector(movieDto.getDirector());
        newMovie.setStudio(movieDto.getStudio());
        newMovie.setReleaseDate(movieDto.getReleaseDate());
        newMovie.setAvgVote(movieDto.getAvgVote());
        newMovie.setCast(movieDto.getCast());
        newMovie.setCategory(category);
        newMovie.setGeneres(genres);
        newMovie.setPoster(movieDto.getPoster());
       
        
        
        // 6. Save the movie (you may need a repository for Movie)
        
        try {
			Movie saveMovie = new Movie();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // 7. Create poster URL with poster of saved movie
        // 8. Convert Movie to MovieDto
        // 9. Return MovieDto
        
        
        
        return null;
    }
}
