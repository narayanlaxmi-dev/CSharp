
package com.museum.service;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.museum.dao.ArticleRepository;
import com.museum.entity.Article;
import com.museum.exception.ArticleNotFoundException;

@Service
public class ArticleService {
	
	@Autowired
	private ArticleRepository articleRepo;
	
	public Article addArticle(Article article) {
		Article savedArticle =articleRepo.save(article);
		return savedArticle;
		
	}
	
	public Collection<Article> getAllArticles(){
List<Article> articles =articleRepo.findAll();
return articles;
		
	}
	public Article getArticleById(Integer id) {
	Article foundArticle =articleRepo.findById(id)
	.orElseThrow(()->new ArticleNotFoundException("Article not found of give id"+ id));
		return foundArticle;
	}
	public String deleteArticleById(Integer id) {
		Article foundArticle =articleRepo.findById(id)
		.orElseThrow(()->new ArticleNotFoundException("Article not found of give id"+ id));
		  articleRepo.deleteById(id);
		  return "article of id "+id+ " deleted";
			
		}
	
	public Article updateArticleById(Integer id,Article updatedArtcile) {
		
		Article foundArticle =articleRepo.findById(id)
				.orElseThrow(()->new ArticleNotFoundException("Article not found of give id"+ id));
		foundArticle.setName(updatedArtcile.getName());
		foundArticle.setCategory(updatedArtcile.getCategory());
		foundArticle.setCreatedDate(updatedArtcile.getCreatedDate());
		foundArticle.setCreatedName(updatedArtcile.getCreatedName());
		
		Article article =articleRepo.save(foundArticle);
		return article;
	}

}