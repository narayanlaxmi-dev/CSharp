package com.museum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MuseumSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MuseumSystemApplication.class, args);
	}

}
