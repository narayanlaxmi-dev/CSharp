package com.mueseum.entity;

public enum Category {

	PAINTING,SCULPTURE,ARTIFACT
}
