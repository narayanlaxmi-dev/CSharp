namespace Blazor.AdminLte.Security.Abstractions.Entities;

public enum Role
{
    Admin,
    User
}