namespace Blazor.AdminLte.Security.Abstractions.Models.Accounts;

public class RevokeTokenRequest
{
    public string Token { get; set; }
}