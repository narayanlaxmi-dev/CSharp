namespace Blazor.AdminLte.Security.Abstractions.Authorization;

[AttributeUsage(AttributeTargets.Method)]
public class AllowAnonymousAttribute : Attribute
{ }