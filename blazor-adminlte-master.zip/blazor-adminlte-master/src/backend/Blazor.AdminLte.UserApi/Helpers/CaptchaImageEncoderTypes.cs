﻿namespace Blazor.AdminLte.UserApi.Helpers
{
    public enum CaptchaImageEncoderTypes
    {
        Jpeg,
        Png,
    }
}
