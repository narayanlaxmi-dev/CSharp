﻿using Microsoft.AspNetCore.Components;
using System.Threading.Tasks;

namespace Blazor.AdminLte.Server.Pages
{
    public partial class Home
    {

    }

}
