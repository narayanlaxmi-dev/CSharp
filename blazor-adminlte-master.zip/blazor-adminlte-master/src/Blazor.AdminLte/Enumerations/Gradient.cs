﻿namespace Blazor.AdminLte
{
    public enum Gradient
    {
        [Style("")]
        None,
        [Style("gradient")]
        Gradient
    }
}
