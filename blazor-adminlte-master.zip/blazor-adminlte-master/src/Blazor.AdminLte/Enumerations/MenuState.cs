﻿namespace Blazor.AdminLte
{
    public enum MenuState
    {
        [Style("closed")]
        Closed,
        [Style("open")]
        Open
    }
}
