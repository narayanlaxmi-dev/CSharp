﻿namespace Blazor.AdminLte
{
    public enum NavLinkState
    {
        [Style("")]
        Inactive,
        [Style("active")]
        Active
    }
}
