﻿namespace Blazor.AdminLte
{
    public enum ButtonType
    {
        [Style("")]
        Solid,
        [Style("outline")]
        Outline,
        [Style("gradient")]
        Gradient
    }
}
