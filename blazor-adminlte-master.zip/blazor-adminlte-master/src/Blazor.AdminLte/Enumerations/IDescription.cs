﻿namespace Blazor.AdminLte
{
    public interface IDescription
    {
        string Description { get; set; }
    }
}