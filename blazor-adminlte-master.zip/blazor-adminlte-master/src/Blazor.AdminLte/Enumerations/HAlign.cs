﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blazor.AdminLte
{
    public enum HAlign
    {
        [Style("center")]
        Center,
        [Style("left")]
        Left,
        [Style("right")]
        Right
    }
}
