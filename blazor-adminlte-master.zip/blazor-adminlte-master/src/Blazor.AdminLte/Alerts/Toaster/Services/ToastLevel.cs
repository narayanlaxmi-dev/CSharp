﻿namespace Blazor.AdminLte.Alerts.Toaster.Services
{
    public enum ToastLevel
    {
        Info,
        Success,
        Warning,
        Error
    }
}
