namespace Blazor.AdminLte.Alerts.Toaster.Configuration
{
    public enum ToastPosition
    {
        TopLeft,
        TopRight,
        TopCenter,
        BottomLeft,
        BottomRight,
        BottomCenter
    }
}