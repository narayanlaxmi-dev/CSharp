﻿namespace Blazor.AdminLte
{
    public interface IDropdownFooter
    {
        string Link { get; set; }
    }
}
