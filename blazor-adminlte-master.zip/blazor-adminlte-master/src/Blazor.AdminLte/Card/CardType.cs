﻿namespace Blazor.AdminLte
{
    public enum CardType
    {
        [Style("")]
        Default,
        [Style("card-tabs")]
        Tabs
    }
}
