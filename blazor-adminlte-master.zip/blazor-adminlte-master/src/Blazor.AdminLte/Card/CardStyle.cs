﻿namespace Blazor.AdminLte
{
    public enum CardStyle
    {
        None,
        Outline,
        OutlineTabs,
        Solid,
        Primary
    }
}
