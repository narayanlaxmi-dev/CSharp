﻿using Microsoft.AspNetCore.Components;

namespace Blazor.AdminLte
{
    partial class CardTitle
    {
        [Parameter]
        public RenderFragment ChildContent { get; set; }
    }
}
