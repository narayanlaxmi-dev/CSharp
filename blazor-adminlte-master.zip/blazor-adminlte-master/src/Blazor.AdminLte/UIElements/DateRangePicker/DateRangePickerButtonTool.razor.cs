﻿namespace Blazor.AdminLte.UIElements.DateRangePicker
{
    public partial class DateRangePickerButtonTool
    {

    }
}
