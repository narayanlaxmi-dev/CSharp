# react-dotnet-example
Example Project on how to develop and build React project with DOTNET Core Web API
