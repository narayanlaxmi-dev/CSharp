namespace react_dotnet_example.Models
{
    public class UserModel
    {
        public int Id { get; set; }
        
        public string firstName { get; set; }

        public string lastName { get; set; }

        public string email { get; set; }
    }
}