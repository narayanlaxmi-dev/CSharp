namespace TodoApp.Models
{
  public class TodoItem
  {
    public string Description {get; set;}
    public string Id {get;set;}
    public bool IsCompleted {get; set;}
  }
}